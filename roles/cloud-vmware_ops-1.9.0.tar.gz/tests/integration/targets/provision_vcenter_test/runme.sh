#!/usr/bin/env bash
source ../init.sh
exec ansible-playbook run.yml
